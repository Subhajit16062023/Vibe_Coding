import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface ChatMessage {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  sessionId: string;
}

export interface ChatSession {
  id: string;
  startTime: Date;
  messages: ChatMessage[];
}

@Injectable({
  providedIn: 'root'
})
export class ChatService {
  private readonly STORAGE_KEY = 'telecom_chat_sessions';
  private messagesSubject = new BehaviorSubject<ChatMessage[]>([]);
  private currentSessionId: string;
  private sessions: { [key: string]: ChatSession } = {};

  constructor() {
    this.loadSessions();
    this.currentSessionId = this.generateSessionId();
    this.initializeSession();
  }

  private generateSessionId(): string {
    return 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  private loadSessions(): void {
    const stored = localStorage.getItem(this.STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        // Convert date strings back to Date objects
        Object.keys(parsed).forEach(sessionId => {
          parsed[sessionId].startTime = new Date(parsed[sessionId].startTime);
          parsed[sessionId].messages.forEach((msg: any) => {
            msg.timestamp = new Date(msg.timestamp);
          });
        });
        this.sessions = parsed;
      } catch (error) {
        console.error('Failed to load chat sessions:', error);
        this.sessions = {};
      }
    }
  }

  private saveSessions(): void {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.sessions));
    } catch (error) {
      console.error('Failed to save chat sessions:', error);
    }
  }

  private initializeSession(): void {
    if (!this.sessions[this.currentSessionId]) {
      this.sessions[this.currentSessionId] = {
        id: this.currentSessionId,
        startTime: new Date(),
        messages: []
      };
      
      // Add welcome message
      this.addSystemMessage('Welcome to Telecom Support! How can I assist you today?');
    }
    
    this.messagesSubject.next(this.sessions[this.currentSessionId].messages);
  }

  getMessages(): Observable<ChatMessage[]> {
    return this.messagesSubject.asObservable();
  }

  addMessage(text: string, isUser: boolean = true): ChatMessage {
    const message: ChatMessage = {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      text: text,
      isUser: isUser,
      timestamp: new Date(),
      sessionId: this.currentSessionId
    };

    this.sessions[this.currentSessionId].messages.push(message);
    this.messagesSubject.next(this.sessions[this.currentSessionId].messages);
    this.saveSessions();

    return message;
  }

  addSystemMessage(text: string): ChatMessage {
    return this.addMessage(text, false);
  }

  generateBotResponse(userMessage: string): string {
    const message = userMessage.toLowerCase();
    
    const responses: { [key: string]: string } = {
      'hello': 'Hello! I\'m your Telecom Assistant. How can I help you today?',
      'hi': 'Hi there! I\'m here to assist you with telecom services and support.',
      'help': 'I can help you with: Network status, Service plans, Billing inquiries, Technical support, and Account management.',
      'network': 'Our network is currently operating at 99.8% uptime. All regions are showing optimal performance.',
      'billing': 'For billing inquiries, I can help you check your current balance, payment history, or explain charges.',
      'support': 'Our technical support team is available 24/7. What specific issue are you experiencing?',
      'plans': 'We offer various service plans including Mobile, Internet, TV, and Business packages. Which one interests you?',
      'status': 'Current system status: All services operational. Network uptime: 99.8%. No reported outages.',
      'thanks': 'You\'re welcome! Is there anything else I can help you with?',
      'bye': 'Thank you for using our services. Have a great day!',
      'price': 'Our pricing varies by service. Mobile plans start at $29.99, Internet at $39.99, and TV packages at $49.99.',
      'outage': 'I\'ll check for any reported outages in your area. Please provide your zip code for specific information.',
      'speed': 'Our internet speeds range from 25 Mbps basic to 1 Gbps ultra-high speed. What speed do you need?',
      'upgrade': 'I can help you upgrade your service. What type of upgrade are you looking for?',
      'downgrade': 'I understand you want to adjust your plan. Let me show you available options.',
      'payment': 'You can make payments online, by phone, or at our retail locations. Would you like payment assistance?',
      'technical': 'I\'m here to help with technical issues. Can you describe the problem you\'re experiencing?'
    };

    for (const keyword in responses) {
      if (message.includes(keyword)) {
        return responses[keyword];
      }
    }

    const defaultResponses = [
      'I understand you need help. Could you please provide more details?',
      'Let me connect you with the right information. Can you be more specific?',
      'I\'m here to help! Could you rephrase your question?',
      'For complex inquiries, I recommend contacting our support team at 1-800-TELECOM.',
      'That\'s an interesting question. Can you tell me more about what you\'re looking for?'
    ];

    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
  }

  clearCurrentSession(): void {
    this.sessions[this.currentSessionId] = {
      id: this.currentSessionId,
      startTime: new Date(),
      messages: []
    };
    
    this.addSystemMessage('Chat cleared. How can I help you?');
    this.saveSessions();
  }

  startNewSession(): void {
    this.currentSessionId = this.generateSessionId();
    this.initializeSession();
  }

  getAllSessions(): ChatSession[] {
    return Object.values(this.sessions).sort((a, b) => 
      b.startTime.getTime() - a.startTime.getTime()
    );
  }

  getSessionById(sessionId: string): ChatSession | undefined {
    return this.sessions[sessionId];
  }

  switchToSession(sessionId: string): void {
    if (this.sessions[sessionId]) {
      this.currentSessionId = sessionId;
      this.messagesSubject.next(this.sessions[this.currentSessionId].messages);
    }
  }

  getTotalMessageCount(): number {
    return Object.values(this.sessions).reduce((total, session) => {
      return total + session.messages.length;
    }, 0);
  }

  getSessionCount(): number {
    return Object.keys(this.sessions).length;
  }

  exportChatHistory(): string {
    const exportData = {
      exportDate: new Date().toISOString(),
      totalSessions: this.getSessionCount(),
      totalMessages: this.getTotalMessageCount(),
      sessions: this.sessions
    };
    
    return JSON.stringify(exportData, null, 2);
  }

  importChatHistory(jsonData: string): boolean {
    try {
      const importData = JSON.parse(jsonData);
      if (importData.sessions) {
        // Convert date strings back to Date objects
        Object.keys(importData.sessions).forEach(sessionId => {
          importData.sessions[sessionId].startTime = new Date(importData.sessions[sessionId].startTime);
          importData.sessions[sessionId].messages.forEach((msg: any) => {
            msg.timestamp = new Date(msg.timestamp);
          });
        });
        
        this.sessions = { ...this.sessions, ...importData.sessions };
        this.saveSessions();
        return true;
      }
      return false;
    } catch (error) {
      console.error('Failed to import chat history:', error);
      return false;
    }
  }
}