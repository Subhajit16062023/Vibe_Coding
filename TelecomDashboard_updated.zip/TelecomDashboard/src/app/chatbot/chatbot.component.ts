import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { ChatService, ChatMessage } from '../services/chat.service';

@Component({
  selector: 'app-chatbot',
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.scss']
})
export class ChatbotComponent implements OnInit, OnDestroy {
  
  isOpen = false;
  messages: ChatMessage[] = [];
  currentMessage = '';
  isTyping = false;
  private messagesSubscription?: Subscription;

  constructor(private chatService: ChatService) { }

  ngOnInit(): void {
    this.messagesSubscription = this.chatService.getMessages().subscribe(
      messages => this.messages = messages
    );
  }

  ngOnDestroy(): void {
    if (this.messagesSubscription) {
      this.messagesSubscription.unsubscribe();
    }
  }

  toggleChatbot(): void {
    this.isOpen = !this.isOpen;
  }

  sendMessage(): void {
    if (!this.currentMessage.trim() || this.isTyping) return;

    const userMessage = this.currentMessage;
    this.currentMessage = '';

    // Add user message
    this.chatService.addMessage(userMessage, true);

    // Show typing indicator
    this.isTyping = true;

    // Simulate bot response delay
    setTimeout(() => {
      this.isTyping = false;
      const botResponse = this.chatService.generateBotResponse(userMessage);
      this.chatService.addMessage(botResponse, false);
      
      // Auto-scroll to bottom
      setTimeout(() => this.scrollToBottom(), 100);
    }, 1000 + Math.random() * 2000);
  }

  quickMessage(message: string): void {
    this.currentMessage = message;
    this.sendMessage();
  }

  onKeyPress(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.sendMessage();
    }
  }

  private scrollToBottom(): void {
    const chatMessages = document.querySelector('.chat-messages');
    if (chatMessages) {
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }
  }

  clearChat(): void {
    this.chatService.clearCurrentSession();
  }

  getSessionStats() {
    return {
      totalSessions: this.chatService.getSessionCount(),
      totalMessages: this.chatService.getTotalMessageCount()
    };
  }
}
