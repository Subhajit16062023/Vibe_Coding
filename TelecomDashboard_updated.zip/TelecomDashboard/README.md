# Telecom Dashboard with Persistent Chatbot

A modern Angular telecom dashboard with Bootstrap styling and an intelligent chatbot that stores conversation history locally.

## Features

- **Bootstrap-Styled Dashboard**: Clean, responsive telecom operations interface
- **KPI Metrics**: Real-time display of customers, revenue, uptime, and services
- **Interactive Charts**: Network performance and customer analytics with Chart.js
- **Persistent Chatbot**: Intelligent support bot with conversation history storage
- **Local Storage**: All chat sessions saved to browser's localStorage
- **Mobile Responsive**: Optimized for desktop, tablet, and mobile devices
- **Easy Installation**: Simple Angular setup with Bootstrap dependencies

## Project Structure

```
telecom-dashboard/
├── server/                     # Backend API server
│   ├── data/
│   │   └── telecom-mock-data.js   # Telecom data generator
│   └── server.js              # Express.js API server
├── src/                       # Angular frontend source
│   ├── app/
│   │   ├── chatbot/          # Chatbot component
│   │   ├── dashboard/        # Dashboard component
│   │   └── services/         # Data services
│   ├── index.html            # Main HTML template
│   └── styles.scss           # Global styles
├── index.html                # Static demo version
├── angular.json              # Angular configuration
├── tsconfig.json             # TypeScript configuration
└── README.md                 # This file
```

## Installation & Setup

### Prerequisites
- Node.js (v18 or higher)
- npm (v8 or higher)
- Angular CLI (v17 or higher)

### Backend Setup
```bash
# Navigate to server directory
cd server

# Install dependencies
npm install express cors

# Start the API server
node server.js
```

The backend server will run on `http://localhost:8000` with the following endpoints:
- `/api/dashboard-metrics` - KPI metrics
- `/api/network-status` - Network status by region
- `/api/recent-alerts` - System alerts
- `/api/health` - Health check

### Angular Setup with Bootstrap
```bash
# Install Angular CLI globally (if not installed)
npm install -g @angular/cli

# Install project dependencies
npm install @angular/core@16 @angular/common@16 @angular/forms@16 \
  @angular/platform-browser@16 @angular/platform-browser-dynamic@16 \
  bootstrap@5.3.2 chart.js rxjs zone.js typescript

# Start the backend server (in separate terminal)
cd server && npm install && npm start

# Start the frontend server
python3 -m http.server 5000 --bind 0.0.0.0
```

### Quick Demo Setup
Use the included standalone HTML version for immediate testing:
```bash
# Open simple-telecom-dashboard.html in your browser
# Or serve it via HTTP server
python3 -m http.server 5000
```

## API Endpoints

### Dashboard Metrics
```
GET /api/dashboard-metrics
Response: {
  "totalCustomers": 2847593,
  "monthlyRevenue": 89750000,
  "networkUptime": 99.8,
  "activeServices": 15842
}
```

### Network Status
```
GET /api/network-status
Response: [
  {
    "region": "North America",
    "status": "Active",
    "uptime": 99.9,
    "latency": 12
  }
]
```

### Recent Alerts
```
GET /api/recent-alerts
Response: [
  {
    "time": "2025-06-20 14:30",
    "type": "Network",
    "message": "High latency detected in Asia Pacific region",
    "severity": "Medium"
  }
]
```

## Chatbot Features

The integrated support chatbot provides:
- **Persistent Conversations**: All chat sessions stored locally
- **Session Management**: Multiple conversation threads with unique IDs
- **Real-time Responses**: Contextual telecom support answers
- **Export/Import**: Backup and restore conversation history
- **Mobile Responsive**: Optimized chat interface for all devices

### Available Support Topics
- Network status and performance monitoring
- Billing inquiries and account management
- Technical support and troubleshooting
- Service plans and package information
- System alerts and maintenance updates

## Technology Stack

### Frontend
- Angular 16+ with Bootstrap 5
- Chart.js for interactive visualizations
- TypeScript for type safety
- SCSS for responsive styling
- Local Storage API for persistence

### Standalone Version
- Pure HTML5/CSS3/JavaScript
- Bootstrap 5 for responsive design
- Chart.js for data visualization
- No external dependencies required

## Development Features

- **Responsive Design**: Adapts to different screen sizes
- **Real-time Data**: API integration with fallback support
- **Professional UI**: Material Design components
- **Interactive Charts**: Powered by Chart.js
- **Cross-platform**: Works on desktop and mobile browsers

## Deployment

### Production Build
```bash
# Build Angular application
ng build --prod

# Start production server
npm start
```

### Environment Configuration
- Development: Frontend (port 5000) + Backend (port 8000)
- Production: Single server serving both frontend and API

## Browser Support
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## License
MIT License - Feel free to use this project for educational and commercial purposes.

## Support
For technical support or questions about the telecom dashboard, please contact the development team.