# Telecom Dashboard - Bootstrap Edition

A clean Angular telecom dashboard with Bootstrap styling and persistent chatbot functionality.

## Features

- **Bootstrap 5 UI**: Modern responsive interface without Material Design dependencies
- **Real-time KPI Metrics**: Customer count, revenue, uptime, and service statistics
- **Interactive Charts**: Network performance and customer analytics with Chart.js
- **Persistent Chatbot**: Support bot with localStorage conversation history
- **Mobile Responsive**: Optimized for all device sizes
- **Zero Material Dependencies**: Pure Angular with Bootstrap only

## Quick Setup

### Option 1: Standalone Demo (No Installation)
```bash
# Open in browser
open simple-telecom-dashboard.html
```

### Option 2: Angular Development
```bash
# Install Angular CLI
npm install -g @angular/cli

# Install dependencies
npm install

# Start backend server
cd server && npm install && npm start

# Start frontend (in new terminal)
ng serve --host 0.0.0.0 --port 5000
```

### Option 3: Static Hosting
```bash
# Serve with any HTTP server
python3 -m http.server 5000
# or
npx serve .
```

## Project Structure

```
├── src/
│   ├── app/
│   │   ├── dashboard/          # Main dashboard component
│   │   ├── chatbot/           # Persistent chatbot component
│   │   └── services/          # API and chat services
│   ├── styles.scss            # Bootstrap-only styles
│   └── index.html             # Main app template
├── server/                    # Express.js backend
├── simple-telecom-dashboard.html  # Standalone demo
└── README.md
```

## Chatbot Features

- **Local Storage**: Conversations saved in browser
- **Session Management**: Multiple chat threads with unique IDs
- **Export/Import**: Backup and restore chat history
- **Contextual Responses**: Telecom-specific support answers
- **Mobile Optimized**: Full-screen mode on mobile devices

## API Endpoints

- `GET /api/dashboard-metrics` - KPI metrics
- `GET /api/network-status` - Network status by region
- `GET /api/recent-alerts` - System alerts
- `GET /api/health` - Backend health check

## Dependencies

### Core Angular
- @angular/core ^16.0.0
- @angular/common ^16.0.0
- @angular/forms ^16.0.0

### UI Framework
- bootstrap ^5.3.2
- chart.js ^4.4.0

### No Material Design dependencies

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## License

MIT License - Free for commercial and personal use.