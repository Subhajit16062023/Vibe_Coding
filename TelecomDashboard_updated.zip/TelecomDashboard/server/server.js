const express = require('express');
const cors = require('cors');
const path = require('path');
const { getTelecomData } = require('./data/telecom-mock-data');

const app = express();
const PORT = process.env.PORT || 8000;

// Middleware - Allow all origins for development
app.use(cors({
  origin: true,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-requested-with']
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the root directory
app.use(express.static(path.join(__dirname, '../')));

// In-memory data storage following the javascript_mem_db blueprint
let telecomData = getTelecomData();

// Logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});

// API Routes
app.get('/api/dashboard-metrics', (req, res) => {
  try {
    const metrics = {
      totalCustomers: telecomData.customers.total,
      monthlyRevenue: telecomData.revenue.monthly,
      networkUptime: telecomData.network.uptime,
      activeServices: telecomData.services.active
    };
    
    res.json(metrics);
  } catch (error) {
    console.error('Error fetching dashboard metrics:', error);
    res.status(500).json({ error: 'Failed to fetch dashboard metrics' });
  }
});

app.get('/api/network-status', (req, res) => {
  try {
    const networkStatus = telecomData.network.regions.map(region => ({
      region: region.name,
      status: region.status,
      uptime: region.uptime,
      latency: region.latency
    }));
    
    res.json(networkStatus);
  } catch (error) {
    console.error('Error fetching network status:', error);
    res.status(500).json({ error: 'Failed to fetch network status' });
  }
});

app.get('/api/recent-alerts', (req, res) => {
  try {
    const alerts = telecomData.alerts.recent.map(alert => ({
      time: alert.timestamp,
      type: alert.type,
      message: alert.message,
      severity: alert.severity
    }));
    
    res.json(alerts);
  } catch (error) {
    console.error('Error fetching recent alerts:', error);
    res.status(500).json({ error: 'Failed to fetch recent alerts' });
  }
});

app.get('/api/network-traffic', (req, res) => {
  try {
    res.json(telecomData.network.traffic);
  } catch (error) {
    console.error('Error fetching network traffic:', error);
    res.status(500).json({ error: 'Failed to fetch network traffic' });
  }
});

app.get('/api/customer-metrics', (req, res) => {
  try {
    res.json(telecomData.customers.metrics);
  } catch (error) {
    console.error('Error fetching customer metrics:', error);
    res.status(500).json({ error: 'Failed to fetch customer metrics' });
  }
});

app.get('/api/service-distribution', (req, res) => {
  try {
    res.json(telecomData.services.distribution);
  } catch (error) {
    console.error('Error fetching service distribution:', error);
    res.status(500).json({ error: 'Failed to fetch service distribution' });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    version: '1.0.0'
  });
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Server error:', error);
  res.status(500).json({ 
    error: 'Internal server error',
    message: error.message,
    timestamp: new Date().toISOString()
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ 
    error: 'Endpoint not found',
    path: req.originalUrl,
    timestamp: new Date().toISOString()
  });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Telecom Dashboard API Server running on http://0.0.0.0:${PORT}`);
  console.log(`📊 Dashboard metrics available at http://0.0.0.0:${PORT}/api/dashboard-metrics`);
  console.log(`🌐 Network status available at http://0.0.0.0:${PORT}/api/network-status`);
  console.log(`⚠️  Recent alerts available at http://0.0.0.0:${PORT}/api/recent-alerts`);
  console.log(`💡 Health check at http://0.0.0.0:${PORT}/api/health`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  process.exit(0);
});
