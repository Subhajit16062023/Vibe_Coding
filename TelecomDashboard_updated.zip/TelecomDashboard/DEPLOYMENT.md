# Telecom Dashboard Deployment Guide

## Production Setup

### Backend Configuration
```bash
# Set production environment
export NODE_ENV=production
export PORT=8000

# Start backend server
cd server
npm install --production
npm start
```

### Frontend Configuration
```bash
# Build for production
ng build --prod

# Serve static files
# The built files will be in the dist/ directory
```

### Environment Variables
```bash
# Backend server
PORT=8000
NODE_ENV=production

# Frontend API endpoint
API_BASE_URL=https://your-domain.com/api
```

### Docker Deployment (Optional)
```dockerfile
# Dockerfile for backend
FROM node:18-alpine
WORKDIR /app
COPY server/ .
RUN npm install --production
EXPOSE 8000
CMD ["npm", "start"]
```

### Health Check Endpoints
- `GET /api/health` - Backend health status
- `GET /api/dashboard-metrics` - Data availability check

### Security Considerations
- Enable CORS for production domains only
- Use HTTPS in production
- Implement rate limiting
- Add authentication for sensitive endpoints

### Performance Optimization
- Enable gzip compression
- Use CDN for static assets
- Implement caching strategies
- Monitor API response times