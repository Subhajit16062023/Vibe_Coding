# Telecom Dashboard with Chatbot

A comprehensive Angular-based telecom operations dashboard featuring real-time metrics, interactive charts, and an integrated support chatbot.

## Features

- **Real-time KPI Dashboard**: Display total customers, monthly revenue, network uptime, and active services
- **Interactive Charts**: Network performance, customer growth, and service distribution visualizations
- **Data Tables**: Network status by region and recent system alerts
- **Integrated Chatbot**: Floating support chatbot with telecom-specific responses
- **Responsive Design**: Works seamlessly on desktop and mobile devices
- **Professional UI**: Material Design-inspired interface with modern styling

## Project Structure

```
telecom-dashboard/
├── server/                     # Backend API server
│   ├── data/
│   │   └── telecom-mock-data.js   # Telecom data generator
│   └── server.js              # Express.js API server
├── src/                       # Angular frontend source
│   ├── app/
│   │   ├── chatbot/          # Chatbot component
│   │   ├── dashboard/        # Dashboard component
│   │   └── services/         # Data services
│   ├── index.html            # Main HTML template
│   └── styles.scss           # Global styles
├── index.html                # Static demo version
├── angular.json              # Angular configuration
├── tsconfig.json             # TypeScript configuration
└── README.md                 # This file
```

## Installation & Setup

### Prerequisites
- Node.js (v18 or higher)
- npm (v8 or higher)
- Angular CLI (v17 or higher)

### Backend Setup
```bash
# Navigate to server directory
cd server

# Install dependencies
npm install express cors

# Start the API server
node server.js
```

The backend server will run on `http://localhost:8000` with the following endpoints:
- `/api/dashboard-metrics` - KPI metrics
- `/api/network-status` - Network status by region
- `/api/recent-alerts` - System alerts
- `/api/health` - Health check

### Frontend Setup (Angular)
```bash
# Install Angular dependencies
npm install @angular/core@17 @angular/common@17 @angular/forms@17 \
  @angular/platform-browser@17 @angular/platform-browser-dynamic@17 \
  @angular/animations@17 @angular/material@17 @angular/cdk@17 \
  rxjs zone.js chart.js typescript

# Start the Angular development server
ng serve --host 0.0.0.0 --port 5000
```

### Quick Demo Setup
For a quick demonstration, you can use the included static HTML version:
```bash
# Serve the static version
python3 -m http.server 5000
```

## API Endpoints

### Dashboard Metrics
```
GET /api/dashboard-metrics
Response: {
  "totalCustomers": 2847593,
  "monthlyRevenue": 89750000,
  "networkUptime": 99.8,
  "activeServices": 15842
}
```

### Network Status
```
GET /api/network-status
Response: [
  {
    "region": "North America",
    "status": "Active",
    "uptime": 99.9,
    "latency": 12
  }
]
```

### Recent Alerts
```
GET /api/recent-alerts
Response: [
  {
    "time": "2025-06-20 14:30",
    "type": "Network",
    "message": "High latency detected in Asia Pacific region",
    "severity": "Medium"
  }
]
```

## Chatbot Features

The integrated chatbot provides support for:
- Network status inquiries
- Billing assistance
- Technical support
- Service plan information
- General telecom operations

### Sample Chatbot Interactions
- "network status" → Current network performance information
- "billing help" → Billing inquiry assistance
- "technical support" → Technical support options
- "service plans" → Available service packages

## Technology Stack

### Frontend
- Angular 17
- Angular Material
- Chart.js for data visualization
- TypeScript
- SCSS for styling

### Backend
- Node.js
- Express.js
- CORS middleware
- In-memory data storage (following javascript_mem_db pattern)

## Development Features

- **Responsive Design**: Adapts to different screen sizes
- **Real-time Data**: API integration with fallback support
- **Professional UI**: Material Design components
- **Interactive Charts**: Powered by Chart.js
- **Cross-platform**: Works on desktop and mobile browsers

## Deployment

### Production Build
```bash
# Build Angular application
ng build --prod

# Start production server
npm start
```

### Environment Configuration
- Development: Frontend (port 5000) + Backend (port 8000)
- Production: Single server serving both frontend and API

## Browser Support
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## License
MIT License - Feel free to use this project for educational and commercial purposes.

## Support
For technical support or questions about the telecom dashboard, please contact the development team.