/**
 * Telecom Mock Data Generator
 * Following the javascript_mem_db blueprint for in-memory data storage
 */

function getTelecomData() {
  const currentDate = new Date();
  const currentHour = currentDate.getHours();
  const currentDay = currentDate.getDate();
  
  return {
    // Customer Data
    customers: {
      total: 2847593,
      metrics: [
        { month: 'January', newCustomers: 25420, churnRate: 2.1, satisfaction: 4.2 },
        { month: 'February', newCustomers: 32150, churnRate: 1.8, satisfaction: 4.3 },
        { month: 'March', newCustomers: 28900, churnRate: 2.3, satisfaction: 4.1 },
        { month: 'April', newCustomers: 35680, churnRate: 1.9, satisfaction: 4.4 },
        { month: 'May', newCustomers: 41230, churnRate: 1.7, satisfaction: 4.5 },
        { month: 'June', newCustomers: 38750, churnRate: 2.0, satisfaction: 4.3 }
      ],
      demographics: {
        residential: 68.5,
        business: 24.2,
        enterprise: 7.3
      }
    },

    // Revenue Data
    revenue: {
      monthly: 89750000,
      quarterly: 267890000,
      yearly: 1045600000,
      breakdown: {
        mobile: 45.2,
        internet: 29.8,
        tv: 15.3,
        business: 9.7
      }
    },

    // Network Infrastructure Data
    network: {
      uptime: 99.8,
      regions: [
        {
          name: 'North America',
          status: 'Active',
          uptime: 99.9,
          latency: 12,
          bandwidth: 850.5,
          customers: 1245789
        },
        {
          name: 'Europe',
          status: 'Active',
          uptime: 99.7,
          latency: 15,
          bandwidth: 720.3,
          customers: 986543
        },
        {
          name: 'Asia Pacific',
          status: 'Warning',
          uptime: 98.5,
          latency: 28,
          bandwidth: 645.8,
          customers: 523876
        },
        {
          name: 'South America',
          status: 'Active',
          uptime: 99.3,
          latency: 22,
          bandwidth: 412.7,
          customers: 76542
        },
        {
          name: 'Africa',
          status: 'Active',
          uptime: 97.8,
          latency: 35,
          bandwidth: 289.4,
          customers: 14843
        }
      ],
      traffic: {
        hourly: generateHourlyTraffic(currentHour),
        daily: generateDailyTraffic(currentDay),
        weekly: generateWeeklyTraffic()
      }
    },

    // Services Data
    services: {
      active: 15842,
      distribution: [
        { service: 'Mobile', percentage: 45, customers: 1281167 },
        { service: 'Internet', percentage: 30, customers: 854378 },
        { service: 'TV', percentage: 15, customers: 427189 },
        { service: 'Business', percentage: 10, customers: 284759 }
      ],
      plans: {
        mobile: [
          { name: 'Basic', price: 29.99, features: ['2GB Data', 'Unlimited Calls'] },
          { name: 'Premium', price: 49.99, features: ['20GB Data', 'International Calls'] },
          { name: 'Unlimited', price: 79.99, features: ['Unlimited Data', 'Premium Support'] }
        ],
        internet: [
          { name: 'Home Basic', price: 39.99, speed: '25 Mbps' },
          { name: 'Home Pro', price: 59.99, speed: '100 Mbps' },
          { name: 'Home Ultra', price: 89.99, speed: '500 Mbps' }
        ]
      }
    },

    // System Alerts
    alerts: {
      recent: [
        {
          id: 1,
          timestamp: '2025-06-20 14:30',
          type: 'Network',
          message: 'High latency detected in Asia Pacific region',
          severity: 'Medium',
          resolved: false
        },
        {
          id: 2,
          timestamp: '2025-06-20 13:15',
          type: 'System',
          message: 'Database backup completed successfully',
          severity: 'Low',
          resolved: true
        },
        {
          id: 3,
          timestamp: '2025-06-20 12:45',
          type: 'Security',
          message: 'Suspicious login attempts blocked',
          severity: 'High',
          resolved: true
        },
        {
          id: 4,
          timestamp: '2025-06-20 11:20',
          type: 'Service',
          message: 'Scheduled maintenance completed',
          severity: 'Low',
          resolved: true
        },
        {
          id: 5,
          timestamp: '2025-06-20 10:10',
          type: 'Network',
          message: 'Router firmware updated successfully',
          severity: 'Low',
          resolved: true
        }
      ],
      summary: {
        total: 5,
        high: 1,
        medium: 1,
        low: 3,
        unresolved: 1
      }
    },

    // Performance Metrics
    performance: {
      kpis: {
        networkAvailability: 99.8,
        customerSatisfaction: 4.3,
        serviceQuality: 96.5,
        responseTime: 0.45
      },
      trends: {
        networkGrowth: 12.5,
        customerGrowth: 8.7,
        revenueGrowth: 15.3
      }
    },

    // Support Data
    support: {
      tickets: {
        open: 2456,
        resolved: 18903,
        avgResolutionTime: 4.2
      },
      channels: {
        phone: 45.2,
        chat: 32.8,
        email: 15.7,
        selfService: 6.3
      }
    }
  };
}

// Helper functions for dynamic data generation
function generateHourlyTraffic(currentHour) {
  const baseTraffic = [120, 115, 105, 95, 85, 90, 110, 140, 165, 180, 185, 190, 
                      195, 185, 175, 180, 190, 200, 195, 185, 170, 155, 140, 130];
  
  // Add some randomness to make it more realistic
  return baseTraffic.map((traffic, index) => ({
    hour: `${index.toString().padStart(2, '0')}:00`,
    traffic: traffic + (Math.random() * 20 - 10), // ±10 variation
    active: index === currentHour
  }));
}

function generateDailyTraffic(currentDay) {
  const traffic = [];
  for (let day = 1; day <= 30; day++) {
    traffic.push({
      day: day,
      traffic: 150 + Math.random() * 50 + Math.sin(day * 0.2) * 20,
      active: day === currentDay
    });
  }
  return traffic;
}

function generateWeeklyTraffic() {
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  return days.map(day => ({
    day: day,
    traffic: 160 + Math.random() * 40,
    isWeekend: day === 'Saturday' || day === 'Sunday'
  }));
}

// Update data periodically to simulate real-time changes
function updateRealTimeData(data) {
  // Update network uptime with small fluctuations
  data.network.uptime = Math.max(97.0, Math.min(100.0, 
    data.network.uptime + (Math.random() * 0.4 - 0.2)));
  
  // Update customer count (slowly growing)
  if (Math.random() < 0.1) { // 10% chance per update
    data.customers.total += Math.floor(Math.random() * 10);
  }
  
  // Update regional latencies
  data.network.regions.forEach(region => {
    region.latency += Math.random() * 6 - 3; // ±3ms variation
    region.latency = Math.max(5, Math.min(100, region.latency));
  });
  
  return data;
}

module.exports = {
  getTelecomData,
  updateRealTimeData
};
