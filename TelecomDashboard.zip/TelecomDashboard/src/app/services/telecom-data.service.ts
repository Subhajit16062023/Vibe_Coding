import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

export interface DashboardMetrics {
  totalCustomers: number;
  monthlyRevenue: number;
  networkUptime: number;
  activeServices: number;
}

export interface NetworkStatus {
  region: string;
  status: string;
  uptime: number;
  latency: number;
}

export interface SystemAlert {
  time: string;
  type: string;
  message: string;
  severity: string;
}

@Injectable({
  providedIn: 'root'
})
export class TelecomDataService {
  
  private baseUrl = 'http://localhost:8000/api';

  constructor(private http: HttpClient) { }

  getDashboardMetrics(): Observable<DashboardMetrics> {
    return this.http.get<DashboardMetrics>(`${this.baseUrl}/dashboard-metrics`)
      .pipe(
        catchError(this.handleError<DashboardMetrics>('getDashboardMetrics', this.getMockDashboardMetrics()))
      );
  }

  getNetworkStatus(): Observable<NetworkStatus[]> {
    return this.http.get<NetworkStatus[]>(`${this.baseUrl}/network-status`)
      .pipe(
        catchError(this.handleError<NetworkStatus[]>('getNetworkStatus', this.getMockNetworkStatus()))
      );
  }

  getRecentAlerts(): Observable<SystemAlert[]> {
    return this.http.get<SystemAlert[]>(`${this.baseUrl}/recent-alerts`)
      .pipe(
        catchError(this.handleError<SystemAlert[]>('getRecentAlerts', this.getMockRecentAlerts()))
      );
  }

  // Fallback mock data methods
  private getMockDashboardMetrics(): DashboardMetrics {
    return {
      totalCustomers: 2847593,
      monthlyRevenue: 89750000,
      networkUptime: 99.8,
      activeServices: 15842
    };
  }

  private getMockNetworkStatus(): NetworkStatus[] {
    return [
      { region: 'North America', status: 'Active', uptime: 99.9, latency: 12 },
      { region: 'Europe', status: 'Active', uptime: 99.7, latency: 15 },
      { region: 'Asia Pacific', status: 'Warning', uptime: 98.5, latency: 28 },
      { region: 'South America', status: 'Active', uptime: 99.3, latency: 22 },
      { region: 'Africa', status: 'Active', uptime: 97.8, latency: 35 }
    ];
  }

  private getMockRecentAlerts(): SystemAlert[] {
    return [
      {
        time: '2025-06-20 14:30',
        type: 'Network',
        message: 'High latency detected in Asia Pacific region',
        severity: 'Medium'
      },
      {
        time: '2025-06-20 13:15',
        type: 'System',
        message: 'Database backup completed successfully',
        severity: 'Low'
      },
      {
        time: '2025-06-20 12:45',
        type: 'Security',
        message: 'Suspicious login attempts blocked',
        severity: 'High'
      },
      {
        time: '2025-06-20 11:20',
        type: 'Service',
        message: 'Scheduled maintenance completed',
        severity: 'Low'
      },
      {
        time: '2025-06-20 10:10',
        type: 'Network',
        message: 'Router firmware updated successfully',
        severity: 'Low'
      }
    ];
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }
}
