import { Component, OnInit } from '@angular/core';

interface ChatMessage {
  text: string;
  isUser: boolean;
  timestamp: Date;
}

@Component({
  selector: 'app-chatbot',
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.scss']
})
export class ChatbotComponent implements OnInit {
  
  isOpen = false;
  messages: ChatMessage[] = [];
  currentMessage = '';
  isTyping = false;

  // Predefined responses for telecom-related queries
  responses: { [key: string]: string } = {
    'hello': 'Hello! I\'m your Telecom Assistant. How can I help you today?',
    'hi': 'Hi there! I\'m here to assist you with telecom services and support.',
    'help': 'I can help you with: Network status, Service plans, Billing inquiries, Technical support, and Account management.',
    'network': 'Our network is currently operating at 99.8% uptime. All regions are showing optimal performance.',
    'billing': 'For billing inquiries, I can help you check your current balance, payment history, or explain charges.',
    'support': 'Our technical support team is available 24/7. What specific issue are you experiencing?',
    'plans': 'We offer various service plans including Mobile, Internet, TV, and Business packages. Which one interests you?',
    'status': 'Current system status: All services operational. Network uptime: 99.8%. No reported outages.',
    'thanks': 'You\'re welcome! Is there anything else I can help you with?',
    'bye': 'Thank you for using our services. Have a great day!'
  };

  constructor() { }

  ngOnInit(): void {
    // Welcome message when component initializes
    this.messages = [{
      text: 'Welcome to Telecom Support! How can I assist you today?',
      isUser: false,
      timestamp: new Date()
    }];
  }

  toggleChatbot(): void {
    this.isOpen = !this.isOpen;
  }

  sendMessage(): void {
    if (!this.currentMessage.trim()) return;

    // Add user message
    const userMessage: ChatMessage = {
      text: this.currentMessage,
      isUser: true,
      timestamp: new Date()
    };
    this.messages.push(userMessage);

    // Clear input and show typing indicator
    const messageText = this.currentMessage.toLowerCase();
    this.currentMessage = '';
    this.isTyping = true;

    // Simulate bot response delay
    setTimeout(() => {
      this.isTyping = false;
      const botResponse = this.getBotResponse(messageText);
      const botMessage: ChatMessage = {
        text: botResponse,
        isUser: false,
        timestamp: new Date()
      };
      this.messages.push(botMessage);
      
      // Auto-scroll to bottom
      setTimeout(() => this.scrollToBottom(), 100);
    }, 1000 + Math.random() * 1000); // Random delay between 1-2 seconds
  }

  getBotResponse(message: string): string {
    // Simple keyword matching for responses
    for (const keyword in this.responses) {
      if (message.includes(keyword)) {
        return this.responses[keyword];
      }
    }

    // Default response
    const defaultResponses = [
      'I understand you need help. Could you please provide more details?',
      'Let me connect you with the right information. Can you be more specific?',
      'I\'m here to help! Could you rephrase your question?',
      'For complex inquiries, I recommend contacting our support team at 1-800-TELECOM.'
    ];

    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
  }

  onKeyPress(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.sendMessage();
    }
  }

  private scrollToBottom(): void {
    const chatMessages = document.querySelector('.chat-messages');
    if (chatMessages) {
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }
  }

  clearChat(): void {
    this.messages = [{
      text: 'Chat cleared. How can I help you?',
      isUser: false,
      timestamp: new Date()
    }];
  }
}
